Build script for linux environment.

* install
1) run buildgp2xtools.sh
2) check excute files in /gp2xsdk/Tools/bin
3) unzipped gp2x-library.tar.gz in /gp2xsdk/Tools/arm-gp2x-linux/

* using
1) set path to /gp2xsdk/Tools/bin
2) using arm-gp2x-linux-gcc or arm-gp2x-linux-g++ or binutils
