#!/bin/sh

export PREFIX="/gp2xsdk/Tools"
export CPU="arm9tdmi"

if test $1; then
  case $1 in
  static)
    export OLDGLIBC="no"
    ;;
  *)
    export OLDGLIBC="yes"
    ;;
  esac
else
  export OLDGLIBC="yes"
fi

if test $OLDGLIBC = "yes"; then
  export GCC="gcc-3.4.6"
  export GCCCORE="gcc-core-3.4.6"
  export GPP="gcc-g++-3.4.6"
  export GCCPREBUILD="gcc-prebuild-3.4.6"
  export GLIBC="glibc-2.2.5"
  export GLIBCADDON="glibc-linuxthreads-2.2.5"
  export TARGET="arm-gp2x-linux"
  export BUILD="$PREFIX/build/gp2x"
else
  export GCC="gcc-4.0.3"
  export GCCCORE="gcc-core-4.0.3"
  export GPP="gcc-g++-4.0.3"
  export GCCPREBUILD="gcc-prebuild-4.0.3"
  export GLIBC="glibc-2.3.6"
  export GLIBCADDON="glibc-linuxthreads-2.3.6"
  export TARGET="arm-gp2xstatic-linux"
  export BUILD="$PREFIX/build/gp2xstatic"
fi

export BINUTILS="binutils-2.16.1"
export KERNELSVN="http://svn.gp2x.com/gp2x/tag/kernel/1.4.0/include/"
export USE_GCCPATCH="no"

UNAME=`uname 2>/dev/null` || UNAME=unknown

case $UNAME in
CYGWIN*)
  export USE_CYGWIN="yes"
  export HOST="i686-pc-cygwin"
  ;;
Linux*)
  export USE_CYGWIN="no"
  export HOST="i386-linux"
  ;;
*)
  echo "unknown host os $UNAME... terminate..."
  exit
  ;;
esac

export FILES="$PREFIX/files"
export PATCHES="$PREFIX/files"
export SOURCE="$PREFIX/src"
export KERNELPATH="$PREFIX/kernel"
export KERNEL="$KERNELPATH/linux-2.4.25-gp2x"

export CROSSBIN="--prefix=$PREFIX --includedir=$PREFIX/$TARGET/include --host=$HOST --target=$TARGET --build=$HOST --program-prefix=$TARGET- --with-cpu=$CPU"
export CROSSLIB="--prefix=$PREFIX/$TARGET --host=$TARGET --build=$HOST --with-cpu=$CPU"

mkdir -p "$PREFIX/bin"
export PATH="$PREFIX/bin:$PATH"

# check patch files
mkdir -p "$PATCHES"
# check gcc, gcc-prebuild patch
if test $USE_GCCPATCH = "yes"; then
  if test ! -f "$PATCHES/$GCC.patch" ; then
    if test ! -f "$GCC.patch" ; then
      echo "Error : Not found gcc.patch";
      exit;
    else
      cp "$GCC.patch" "$PATCHES";
    fi
  fi
fi
if test ! -f "$PATCHES/$GCCPREBUILD.patch" ; then
  if test ! -f "$GCCPREBUILD.patch" ; then
    echo "Error : Not found gcc-prebuild.patch";
    exit;
  else
    cp "$GCCPREBUILD.patch" "$PATCHES";
  fi
fi

# check glibc patches
if test $USE_CYGWIN = "yes"; then
  if test ! -f "$PATCHES/$GCC-$GLIBC-cygwin.patch" ; then
    if test ! -f "$GCC-$GLIBC-cygwin.patch" ; then
      echo "Error : Not found glibc-cygwin.patch";
      exit;
    else
      cp "$GCC-$GLIBC-cygwin.patch" "$PATCHES";
    fi
  fi
else
  if test ! -f "$PATCHES/$GCC-$GLIBC.patch" ; then
    if test ! -f "$GCC-$GLIBC.patch" ; then
      echo "Error : Not found gcc-glibc.patch";
      exit;
    else
      cp "$GCC-$GLIBC.patch" "$PATCHES"
    fi
  fi
fi

# download sources
mkdir -p "$FILES"
cd "$FILES"

# binutils source
if test ! -f "$BINUTILS.tar.bz2" ; then
  wget ftp://ftp.gnu.org/gnu/binutils/$BINUTILS.tar.bz2 || { echo "Error : Failed downloading binutils"; exit; }
fi

# gcc source
if test ! -f "$GCCCORE.tar.bz2" ; then
  wget ftp://ftp.gnu.org/gnu/gcc/$GCC/$GCCCORE.tar.bz2 || { echo "Error : Failed downloading gcc-core"; exit; }
fi
if test ! -f "$GPP.tar.bz2" ; then
  wget ftp://ftp.gnu.org/gnu/gcc/$GCC/$GPP.tar.bz2 || { echo "Error : Failed downloading gcc-g++"; exit; }
fi

# glibc source
if test $OLDGLIBC = "yes"; then
  if test ! -f "$GLIBC.tar.gz" ; then
    wget -c ftp://ftp.gnu.org/gnu/glibc/$GLIBC.tar.gz || { echo "Error : Failed downloading glibc"; exit; }
  fi
  if test ! -f "$GLIBCADDON.tar.gz" ; then
    wget -c ftp://ftp.gnu.org/gnu/glibc/$GLIBCADDON.tar.gz || { echo "Error : Failed downloading glibc-linuxthreads"; exit; }
  fi
else
  if test ! -f "$GLIBC.tar.bz2" ; then
    wget -c ftp://ftp.gnu.org/gnu/glibc/$GLIBC.tar.bz2 || { echo "Error : Failed downloading glibc"; exit; }
  fi
  if test ! -f "$GLIBCADDON.tar.bz2" ; then
    wget -c ftp://ftp.gnu.org/gnu/glibc/$GLIBCADDON.tar.bz2 || { echo "Error : Failed downloading glibc-addon"; exit; }
  fi
fi

# kernel source
mkdir -p "$KERNEL"
cd "$KERNEL"
if test ! -d "$KERNEL/include" ; then
  svn export "$KERNELSVN" "$KERNEL/include" || { echo "Error : Failed downloading kernel source"; exit; }
fi
cd "$KERNEL/include"
if test ! -e "asm" ; then
  if test ! -d "asm-arm" ; then
    echo "Error : Failed downloading kernel source";
    exit;
  fi
  ln -s "asm-arm" "asm"
fi
cd "$KERNEL/include/asm"
if test ! -e "arch" ; then
  if test ! -d "arch-mmsp2" ; then
    echo "Error : Failed downloading kernel source";
    exit;
  fi
  ln -s "arch-mmsp2" "arch"
fi
if test ! -e "proc" ; then
  if test ! -d "proc-armv" ; then
    echo "Error : Failed downloading kernel source";
    exit;
  fi
  ln -s "proc-armv" "proc"
fi

# extract sources
mkdir -p "$SOURCE"
if test ! -d "$SOURCE/$BINUTILS" ; then
  tar -jxvf "$FILES/$BINUTILS.tar.bz2" -C "$SOURCE"
fi

if test ! -d "$SOURCE/$GCC" ; then
  rm -rf "$SOURCE/$GCCPREBUILD"
  tar -jxvf "$FILES/$GCCCORE.tar.bz2" -C "$SOURCE"
  mv "$SOURCE/$GCC" "$SOURCE/$GCCPREBUILD"
  cd "$SOURCE/$GCCPREBUILD"
  patch -p1 < "$PATCHES/$GCCPREBUILD.patch"

  tar -jxvf "$FILES/$GCCCORE.tar.bz2" -C "$SOURCE"
  tar -jxvf "$FILES/$GPP.tar.bz2" -C "$SOURCE"

  if test $USE_GCCPATCH = "yes"; then
    cd "$SOURCE/$GCC"
    patch -p1 < "$PATCHES/$GCC.patch"
  fi
fi

if test ! -d "$SOURCE/$GLIBC" ; then
  if test $OLDGLIBC = "yes"; then
    tar -zxvf "$FILES/$GLIBC.tar.gz" -C "$SOURCE"
    tar -zxvf "$FILES/$GLIBCADDON.tar.gz" -C "$SOURCE/$GLIBC"
  else
    tar -jxvf "$FILES/$GLIBC.tar.bz2" -C "$SOURCE"
    tar -jxvf "$FILES/$GLIBCADDON.tar.bz2" -C "$SOURCE/$GLIBC"
  fi
  cd "$SOURCE/$GLIBC"

  if test $USE_CYGWIN = "yes"; then
    patch -p1 < "$PATCHES/$GCC-$GLIBC-cygwin.patch"
  else
    patch -p1 < "$PATCHES/$GCC-$GLIBC.patch"
  fi
fi

# binutils
if test ! -f "$PREFIX/bin/$TARGET-ld" && test ! "`$TARGET-ld -v`" ; then
  echo "Build : binutils"
  mkdir -p "$BUILD/binutils"
  cd "$BUILD/binutils"
  $SOURCE/$BINUTILS/configure $CROSSBIN --disable-nls
  make && make install
  if test ! -f "$PREFIX/bin/$TARGET-ld" && test ! "`$TARGET-ld -v`" ; then
    echo "Error : Failed building binutils"
    exit
  fi
fi

# gcc-prebuild
if test ! -f "$PREFIX/bin/$TARGET-gcc" && test ! "`$TARGET-gcc --version`" ; then
  echo "Build : gcc-prebuild"
  mkdir -p "$BUILD/gcc-prebuild"
  cd "$BUILD/gcc-prebuild"
  $SOURCE/$GCCPREBUILD/configure $CROSSBIN --disable-threads --disable-shared --disable-nls --enable-languages="c" --with-headers=$KERNEL/include --without-fp --with-softfloat-support=internal
  make
  make install
  if test ! -f "$PREFIX/bin/$TARGET-gcc" && test ! "`$TARGET-gcc --version`" ; then
    echo "Error : Failed building gcc-prebuild"
    exit
  fi
fi

# glibc
if test ! -f "$PREFIX/$TARGET/lib/libc.so" ; then
  echo "Build : glibc"
  mkdir -p $BUILD/glibc
  cd $BUILD/glibc
  $SOURCE/$GLIBC/configure $CROSSLIB --with-headers=$KERNEL/include --enable-add-ons=linuxthreads --enable-shared --enable-kernel=2.4.25
  make && make install
  if test ! -f "$PREFIX/$TARGET/lib/libc.so" ; then
    echo "Error : Failed building glibc"
    exit
  fi
fi

# gcc
if test ! -f "$PREFIX/bin/$TARGET-g++" && test ! "`$TARGET-g++ --version`" ; then
  echo "Build : gcc"
  mkdir -p $BUILD/gcc
  cd $BUILD/gcc
  $SOURCE/$GCC/configure $CROSSBIN --with-headers=$KERNEL/include --enable-shared --disable-nls --disable-libstdcxx-pch --without-fp --with-softfloat-support=internal
  make && make install
  which "$TARGET-g++"
  if test ! -f "$PREFIX/bin/$TARGET-g++" && test ! "`$TARGET-g++ --version`" ; then
    echo "Error : Failed building gcc"
    exit
  fi
fi
