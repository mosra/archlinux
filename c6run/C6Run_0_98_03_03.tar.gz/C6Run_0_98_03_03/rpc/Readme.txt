DSP-RPC-POSIX: DSP->GPP Remote Procedure Calls
______________________________________________

Please see the HTML documentation file under the top-level doc/ directory for information on DSP-RPC-POSIX.
