package GCC::Node::Block;
use strict;
use base qw(GCC::Node);

#    'b' for a lexical block.
# DEFTREECODE (BLOCK, "block", 'b', 0)

# vim:set shiftwidth=4 softtabstop=4:
1;
