The most current documentation for the C6Run project can be found on the 
Texas Instrument's Embedded Processor Wiki:

  http://processors.wiki.ti.com/index.php/C6Run_Project


You can also find the latest version of the software at:
  
  http://software-dl.ti.com/dsps/dsps_public_sw/c6000/web/c6run/latest/index_FDS.html

  
You can particpate in this open source project, including filing bugs and 
  feature requests, at the TI GForge page:
  
  https://gforge.ti.com/gf/project/dspeasy/
  
