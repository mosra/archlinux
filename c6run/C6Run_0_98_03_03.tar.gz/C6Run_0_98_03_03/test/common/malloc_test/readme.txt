Description: 
  Call a function with greater than MAX_ARG_CNT arguments.
Tests: 
  Backend C6RunLib framework remote procedure call failure mechanism.
Expected Result: 
  The framework should report an error and fail gracefully.