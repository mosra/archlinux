Description: 
  Call collection of functions with coverage of scalar return types (all 
  built-in C integer and real types)
Tests: 
  Frontend tools ability to handle return types and framework tools 
  ability to receive results of remote procedure calls
Expected Result: 
  Functions with built-in scalar return types can be compiled through C6RunLib
  framework and called successfully.
                 