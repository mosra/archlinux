Description: 
  Call collection of functions with coverage of scalar pass-by-value arguments
  (all built-in C integer and real types).
Tests: 
  Frontend tools ability to handle argument types and framework tools ability
  to pass arguments to remote procedures.
Expected Result: 
  Functions with built-in scalar args can be compiled through C6RunLib framework
  and called successfully.
                 