Description: 
  Call a simple function that does some work and then reports DSP load.
Tests: 
  C6RUN_UTIL_getLoad APIs
Expected Result: 
  Prints DSP load for various workloads.