Description: 
  Simple test of generated asynchronous API usage.
Tests: 
  Verifies that asynchronous APIs are generated properly, are callable.
Expected Result: 
  While one async API is in executing on the DSP, other synchronous calls
  can be made to the DSP without issue.