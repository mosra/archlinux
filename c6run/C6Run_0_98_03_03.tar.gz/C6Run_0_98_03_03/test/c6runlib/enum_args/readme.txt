Description: 
  Call functions using enums arguments (both typedefed and not-typedefed).
Tests: 
  Frontend tools ability to handle enum types appropriately.
Expected Result: 
  Functions with enum args can be compiled through C6RunLib framework and 
  called successfully.
                 