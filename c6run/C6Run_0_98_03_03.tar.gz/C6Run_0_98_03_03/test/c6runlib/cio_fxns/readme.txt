Description: 
  From within one or more remote procedures, call various C I/O functions
Tests: 
  Backend C6RunLib framework's CIO server availability/functionality in the
  middle of a remote procedure call.
Expected Result: 
  All CIO operations complete/function as expected.