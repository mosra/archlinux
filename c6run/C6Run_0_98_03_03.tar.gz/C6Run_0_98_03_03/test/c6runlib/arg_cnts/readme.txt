Description: 
  Call a collection of functions varying from 0 to MAX_ARG_CNT arguments.
Tests: 
  Backend C6RunLib framework remote procedure call mechanisms.
Expected Result: 
  All arguments for all functions are passed and used correctly.