Description: 
  Call functions with pointer arguments specified as NONE types, and 
  manually use C6RUN_MEM caching APIs.
Tests: 
  Manual use of caching APIs and NONE buffer types, manual testing of 
  global cache ops.
Expected Result: 
  Manual use of cache APIs matches the automated use of the same.
                 