Description: 
  Call functions that return enum results (both typedefed and not-typedefed).
Tests: 
  Frontend tools and backend libraries ability to handle enum return types appropriately.
Expected Result: 
  Functions with enum return types can be compiled through C6RunLib framework
  and called successfully.
  