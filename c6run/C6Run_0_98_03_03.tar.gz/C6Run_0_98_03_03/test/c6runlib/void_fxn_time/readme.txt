Description: 
  Call a simple function with no args and measure the average round-trip call time
Tests: 
  Interprocessor communication time of underlying IPC software
Expected Result: 
  Prints average time required for a synchronous round trip function call.