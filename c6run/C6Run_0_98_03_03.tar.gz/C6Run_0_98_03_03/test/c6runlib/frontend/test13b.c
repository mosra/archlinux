#include <stdio.h>

#define TESTNUM "13"

long long test13_ll( void )
{
  printf("Running Test #" TESTNUM ".\n");
  
  return 0;
}

double test13_d(void)
{
  printf("Running Test #" TESTNUM ".\n");
  
  return 1.0;
}
