#include <stdio.h>

#define TESTNUM "12"

short test12_s( void )
{
  printf("Running Test #" TESTNUM ".\n");
  
  return 1;
}

