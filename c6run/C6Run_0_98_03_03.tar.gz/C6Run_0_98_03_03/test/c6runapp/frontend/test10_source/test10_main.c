#include <stdio.h>

extern void test10_extra(void);

int main( void )
{
  printf("Running Test #10.\n");
  
  test10_extra();
}
