#include <stdio.h>

void test10_extra( void )
{
  printf(" Test #10 extra.\n");
}
