#include <stdio.h>

extern void test9_extra(void);

int main( void )
{
  printf("Running Test #9.\n");
  
  test9_extra();
}
