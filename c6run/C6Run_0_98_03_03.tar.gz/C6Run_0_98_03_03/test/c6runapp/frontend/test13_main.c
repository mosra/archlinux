#include <stdio.h>

extern void test13_extra(void);

int main( void )
{
  printf("Running Test #13.\n");
  
  test13_extra();
}
