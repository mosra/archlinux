#include <stdio.h>

void test9_extra( void )
{
  printf(" Test #9 extra.\n");
}
