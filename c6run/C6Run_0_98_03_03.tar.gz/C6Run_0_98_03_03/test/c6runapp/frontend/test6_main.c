#include <stdio.h>

int main( void )
{
  printf("Running Test #6.\n");
}
